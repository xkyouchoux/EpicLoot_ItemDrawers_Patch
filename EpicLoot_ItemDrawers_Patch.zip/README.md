**EpicLoot/ItemDrawers Patch**

A simple mod to fix how EpicLoots enchanting materials display on item drawers.
Will not work without [Item Drawers](https://valheim.thunderstore.io/package/makail/ItemDrawers/) and [Epic Loot](https://valheim.thunderstore.io/package/RandyKnapp/EpicLoot/)

Install into **Bepinex/plugins**

Source: [GITHUB](https://github.com/xkyouchoux/EpicLoot_ItemDrawers_Patch)